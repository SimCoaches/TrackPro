from PyQt5.QtWidgets import QWidget, QVBoxLayout
from PyQt5.QtCore import Qt
import pyqtgraph as pg
import numpy as np
import logging

logger = logging.getLogger(__name__)

class SpeedGraphWidget(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        
        # Create the plot widget
        self.plot_widget = pg.PlotWidget()
        self.plot_widget.setBackground('k')  # Black background
        self.plot_widget.setTitle("Speed vs Distance") 
        self.plot_widget.setLabel('bottom', "Distance (m)")
        
        # Configure Left Y-Axis for Speed (km/h)
        left_axis = self.plot_widget.getAxis('left')
        left_axis.setLabel("Speed (km/h)")
        
        # Show grid lines for both axes
        self.plot_widget.showGrid(x=True, y=True, alpha=0.3)
        
        # Disable mouse interaction for zoom/pan
        self.plot_widget.plotItem.vb.setMouseEnabled(x=False, y=False)
        self.plot_widget.setMenuEnabled(False)
        self.plot_widget.plotItem.vb.disableAutoRange()
        
        # Create a standard legend in the top-right corner with default style
        self.legend = self.plot_widget.addLegend(offset=(-20, 10), labelTextSize='10pt')
        
        # Create crosshair lines
        self.vLine = pg.InfiniteLine(angle=90, movable=False, pen=pg.mkPen('w', width=1))
        self.hLine = pg.InfiniteLine(angle=0, movable=False, pen=pg.mkPen('w', width=1))
        self.plot_widget.addItem(self.vLine, ignoreBounds=True)
        self.plot_widget.addItem(self.hLine, ignoreBounds=True)
        
        # Create text label for coordinates
        self.label = pg.TextItem(text='', color='w', anchor=(0, 1))
        self.label.setPos(10, 10)
        self.plot_widget.addItem(self.label, ignoreBounds=True)
        
        # Track context elements
        self.start_finish_line = pg.InfiniteLine(
            angle=90, 
            movable=False, 
            pen=pg.mkPen('y', width=2, style=Qt.DashLine),
            label="Start/Finish", 
            labelOpts={'position': 0.9, 'color': 'y'}
        )
        self.plot_widget.addItem(self.start_finish_line, ignoreBounds=True)
        self.start_finish_line.hide()  # Hide initially
        
        # Container for corner and distance markers
        self.corner_markers = []
        self.distance_markers = []
        self.stopped_section_markers = []
        
        # Track parameters
        self.track_length = 0
        
        # Connect mouse movement for crosshair
        self.plot_widget.scene().sigMouseMoved.connect(self.mouseMoved)
        
        # Setup layout
        layout = QVBoxLayout()
        layout.addWidget(self.plot_widget)
        self.setLayout(layout)
        
        # Initialize plot items - these will be updated by update_graph/update_comparison_data
        self.speed_curve = self.plot_widget.plot(pen=pg.mkPen('#00C8FF', width=2), name="Lap A Speed", autoDownsample=False, clipToView=False)
        self.speed_curve_b = self.plot_widget.plot(pen=pg.mkPen('#88FFFF', width=2, style=Qt.SolidLine), name="Lap B Speed", autoDownsample=False, clipToView=False)
        
        # Initially hide comparison curves
        self.speed_curve_b.hide()
        
        # Initialize empty data list for plot items (no longer used directly for curves)
        self.plot_items = [] 
        
        # Store message text item reference
        self.message_text = None
        
        self.comparison_mode = False # Initialize comparison mode
        
        self.reset_view()
        
    def mouseMoved(self, pos):
        """Handle mouse movement to update crosshairs and tooltip."""
        if self.plot_widget.sceneBoundingRect().contains(pos):
            mousePoint = self.plot_widget.plotItem.vb.mapSceneToView(pos)
            x, y = mousePoint.x(), mousePoint.y()
            
            # Update crosshair positions
            self.vLine.setPos(x)
            self.hLine.setPos(y)
            
            # Find the actual speed values at the cursor position
            speed_value_a = None
            speed_value_b = None
            distance = x
            
            # Find the closest data point from Lap A
            if self.speed_curve.xData is not None and len(self.speed_curve.xData) > 0:
                # Find the closest x point to the cursor
                closest_idx = -1
                min_distance = float('inf')
                
                for i, x_val in enumerate(self.speed_curve.xData):
                    dist = abs(x_val - x)
                    if dist < min_distance:
                        min_distance = dist
                        closest_idx = i
                
                if closest_idx >= 0:
                    # Get actual speed value from the data
                    if closest_idx < len(self.speed_curve.yData):
                        speed_value_a = self.speed_curve.yData[closest_idx]

            # In comparison mode, also get data from Lap B
            if self.comparison_mode and self.speed_curve_b.xData is not None and len(self.speed_curve_b.xData) > 0:
                # Find the closest x point to the cursor
                closest_idx = -1
                min_distance = float('inf')
                
                for i, x_val in enumerate(self.speed_curve_b.xData):
                    dist = abs(x_val - x)
                    if dist < min_distance:
                        min_distance = dist
                        closest_idx = i
                
                if closest_idx >= 0:
                    # Get actual speed value from the data
                    if closest_idx < len(self.speed_curve_b.yData):
                        speed_value_b = self.speed_curve_b.yData[closest_idx]
            
            # Update tooltip label with data
            tooltip_text = f"Distance: {distance:.1f}m"
            
            if speed_value_a is not None:
                tooltip_text += f"\nLap A Speed: {speed_value_a:.1f} km/h"
                
            if speed_value_b is not None:
                tooltip_text += f"\nLap B Speed: {speed_value_b:.1f} km/h"
                
                if speed_value_a is not None:
                    # Calculate and display delta
                    delta = speed_value_b - speed_value_a
                    tooltip_text += f"\nDelta: {delta:+.1f} km/h"
                
            self.label.setText(tooltip_text)
            self.label.setPos(x, y)
            
    def reset_view(self):
        """Reset the view to default parameters."""
        # Set default view ranges for a new/empty plot
        self.plot_widget.setXRange(0, 1000, padding=0)  # Default to 1km track
        
        # Find a reasonable range for Y axis (0 to some max speed)
        self.plot_widget.setYRange(0, 300, padding=0.02)  # Default to max speed 300 km/h
        
    def clear_track_markers(self):
        """Clear all track-related markers."""
        # Remove corner markers
        for marker in self.corner_markers:
            if marker in self.plot_widget.items():
                self.plot_widget.removeItem(marker)
        self.corner_markers = []
        
        # Remove distance markers
        for marker in self.distance_markers:
            if marker in self.plot_widget.items():
                self.plot_widget.removeItem(marker)
        self.distance_markers = []
        
        # Remove stopped section markers
        for marker in self.stopped_section_markers:
            if marker in self.plot_widget.items():
                self.plot_widget.removeItem(marker)
        self.stopped_section_markers = []
        
        # Hide start/finish line
        self.start_finish_line.hide()
    
    def _add_track_context_markers(self, track_context, display_range_max):
        """Add track context markers to the graph.
        
        Args:
            track_context: Dictionary with track information
            display_range_max: Maximum display range for X axis
        """
        if not track_context:
            return
            
        self.clear_track_markers()
        
        # Add track corners
        corners = track_context.get('corners', {})
        for corner_num, corner_data in corners.items():
            distance = corner_data.get('distance', -1)
            if distance >= 0:
                # Add vertical line for corner
                corner_line = pg.InfiniteLine(
                    angle=90, 
                    movable=False, 
                    pen=pg.mkPen('b', width=1, style=Qt.DashLine),
                    label=f"T{corner_num}", 
                    labelOpts={'position': 0.05, 'color': 'b', 'fill': (0, 0, 0, 80)}
                )
                corner_line.setPos(distance)
                self.plot_widget.addItem(corner_line)
                self.corner_markers.append(corner_line)
        
        # Add distance markers (every 100m)
        marker_interval = 100  # meters
        if display_range_max > 5000:
            marker_interval = 500  # Use larger interval for long tracks
        elif display_range_max > 2000:
            marker_interval = 200  # Use medium interval for medium tracks
            
        for distance in range(marker_interval, int(display_range_max), marker_interval):
            # Add vertical line for distance marker
            distance_line = pg.InfiniteLine(
                angle=90, 
                movable=False, 
                pen=pg.mkPen('gray', width=1, style=Qt.DotLine),
                label=f"{distance}m",
                labelOpts={'position': 0.95, 'color': 'gray', 'fill': (0, 0, 0, 50)}
            )
            distance_line.setPos(distance)
            self.plot_widget.addItem(distance_line)
            self.distance_markers.append(distance_line)
            
        # Add start/finish line
        self.start_finish_line.setPos(0)
        self.start_finish_line.show()
    
    def add_stopped_section_marker(self, position, data=None):
        """Add a marker for a section where the car was stopped.
        
        Args:
            position: Distance position along track
            data: Optional dictionary with additional data about the stopped section
        """
        # Create marker to highlight stopped section
        marker = pg.InfiniteLine(
            angle=90, 
            movable=False, 
            pen=pg.mkPen('r', width=2, style=Qt.DotLine),
            label="Stopped", 
            labelOpts={'position': 0.5, 'color': 'r', 'fill': (0, 0, 0, 80)}
        )
        marker.setPos(position)
        self.plot_widget.addItem(marker)
        self.stopped_section_markers.append(marker)
    
    def _detect_stopped_sections(self, distances, speeds, min_points_stop=10, pos_tolerance=0.5):
        """Detect sections where the car appears to have stopped based on distance and speed data."""
        stopped_sections_output = []
        if not distances or len(distances) < min_points_stop:
            return stopped_sections_output

        pos_counts = {}
        point_data = {} # Store first point's data for each bin

        for i, dist in enumerate(distances):
            bin_pos = round(dist / pos_tolerance) * pos_tolerance
            pos_counts[bin_pos] = pos_counts.get(bin_pos, 0) + 1
            if bin_pos not in point_data:
                 # Store speed data for the first point encountered in this bin
                 point_data[bin_pos] = {
                     'avg_speed': speeds[i] if i < len(speeds) else 0,
                     'count': 0 # We'll update count later
                 }

        for pos, count in pos_counts.items():
            if count >= min_points_stop:
                # For the tooltip, let's calculate average speed in the stopped section
                section_data = point_data.get(pos, {'avg_speed': 0})
                section_data['count'] = count # Add the count here
                stopped_sections_output.append((pos, section_data))

        return stopped_sections_output

    def update_graph_comparison(self, lap_a_data, lap_b_data, track_length, track_context=None):
        """Update the graph to display a comparison of two laps."""
        logger.info(f"Updating speed graph with comparison data for A:{len(lap_a_data['points']) if lap_a_data else 'None'} and B:{len(lap_b_data['points']) if lap_b_data else 'None'} points")
        
        # Set comparison mode flag to True
        self.comparison_mode = True
        
        # --- COMPLETELY RESET PLOT STATE ---
        # Clear both curves by setting empty data arrays
        self.speed_curve.setData([], [])
        self.speed_curve_b.setData([], [])
        
        # Reset plot items and state
        if self.legend:
            self.legend.clear()
            
        # Clear all additional items from the plot that might be leftover
        for item in self.plot_widget.items():
            if item not in [self.speed_curve, self.speed_curve_b, self.vLine, self.hLine, self.label, self.start_finish_line]:
                self.plot_widget.removeItem(item)
                
        # Clear any message text
        if hasattr(self, 'message_text') and self.message_text and self.message_text in self.plot_widget.items():
             self.plot_widget.removeItem(self.message_text)
             self.message_text = None
             
        # Clear all track markers
        self.clear_track_markers()
        # --- END COMPLETE RESET ---

        # --- Ensure curves are visible and legend exists --- 
        self.speed_curve.show()
        self.speed_curve_b.show()
        if self.legend is None:
            # Create a new legend with proper styling if it doesn't exist
            self.legend = self.plot_widget.addLegend(offset=(-20, 10), labelTextSize='10pt')
        # ------------------------------------------------

        # Initialize variable for lap processing
        max_dist_overall = 0
        max_speed_overall = 0
        
        # --- Helper Function to Process Lap ---
        def process_lap(lap_dict):
            nonlocal max_dist_overall, max_speed_overall
            points = lap_dict.get('points', [])
            if not points: return None, None

            distances = []
            speed_values = []

            for point in points:
                # Use 'LapDist' key for distance (expecting meters now)
                if 'LapDist' in point:
                    dist = point['LapDist']
                else: continue # Skip if missing distance

                # Get speed value and convert to km/h if needed
                speed = point.get('Speed', point.get('speed', 0))
                if isinstance(speed, (int, float)):
                    # Convert to km/h if speed is in m/s
                    if speed < 100:  # Assuming speeds < 100 are in m/s
                        speed *= 3.6
                
                distances.append(dist)
                speed_values.append(speed)

            if distances:
                max_dist_overall = max(max_dist_overall, max(distances))
                if speed_values:
                    max_speed_overall = max(max_speed_overall, max(speed_values))
                return distances, speed_values
            return None, None
        # --- End Helper ---

        # Process main lap (Lap A)
        main_distances, main_speeds = process_lap(lap_a_data)
        if main_distances:
            self.speed_curve.setData(main_distances, main_speeds)
            logger.info(f"Set Lap A speed data with {len(main_distances)} points")
        else:
            logger.warning("No valid data for Lap A")
            self.speed_curve.hide()

        # Process comparison lap (Lap B)
        comp_distances, comp_speeds = process_lap(lap_b_data)
        if comp_distances:
            self.speed_curve_b.setData(comp_distances, comp_speeds)
            logger.info(f"Set Lap B speed data with {len(comp_distances)} points")
        else:
            logger.warning("No valid data for Lap B")
            self.speed_curve_b.hide() # Ensure hidden if no data

        # Ensure the legend is populated AFTER setting data
        if self.legend:
            self.legend.clear()  # Make sure to clear the legend again before adding items
            if main_distances:
                 self.legend.addItem(self.speed_curve, "Lap A Speed")
            if comp_distances:
                 self.legend.addItem(self.speed_curve_b, "Lap B Speed")

        # Determine track length
        self.track_length = 0
        track_context = lap_a_data.get('track_context') if lap_a_data else (lap_b_data.get('track_context') if lap_b_data else None)
        if lap_a_data and lap_a_data.get('track_length'): self.track_length = lap_a_data['track_length']
        elif lap_b_data and lap_b_data.get('track_length'): self.track_length = lap_b_data['track_length']
        display_range_max = self.track_length if self.track_length > 0 else max(max_dist_overall * 1.05, 1000)

        # Update title and axis ranges
        self.plot_widget.setTitle("Speed vs Distance (Comparison)")
        self.plot_widget.setXRange(0, display_range_max, padding=0)
        
        # Set appropriate Y range with some padding
        y_max = max(max_speed_overall * 1.1, 300)  # Use at least 300 km/h as maximum
        self.plot_widget.setYRange(0, y_max, padding=0.02)
        
        # Add track context markers (should be added after curves)
        self._add_track_context_markers(track_context, display_range_max)
        
        # Re-add crosshairs and labels
        if self.vLine not in self.plot_widget.items(): self.plot_widget.addItem(self.vLine, ignoreBounds=True)
        if self.hLine not in self.plot_widget.items(): self.plot_widget.addItem(self.hLine, ignoreBounds=True)
        if self.label not in self.plot_widget.items(): self.plot_widget.addItem(self.label, ignoreBounds=True)
        
        # Add grid
        self.plot_widget.showGrid(x=True, y=True, alpha=0.3)
        
        # Force a redraw of the plot
        self.plot_widget.update()

    def update_graph(self, lap_data, track_length, track_context=None):
        """Update the graph with new lap data using distance as X-axis."""
        try:
            # Start with clean state - reset all plot elements
            self.comparison_mode = False
            
            # Reset plot items and state
            if self.legend:
                self.legend.clear()
                
            # Hide the comparison curve (not using it in single lap mode)
            self.speed_curve_b.hide()
            
            # Clear all additional items from the plot (except the main components)
            for item in list(self.plot_widget.items()):
                if item not in [self.speed_curve, self.speed_curve_b, self.vLine, self.hLine, self.label, self.start_finish_line]:
                    self.plot_widget.removeItem(item)
                    
            # Clear any message text
            if hasattr(self, 'message_text') and self.message_text and self.message_text in self.plot_widget.items():
                self.plot_widget.removeItem(self.message_text)
                self.message_text = None
                
            # Clear all track markers
            self.clear_track_markers()
            
            # Check for valid data
            if not lap_data:
                logger.warning("No data provided for speed graph")
                self.display_message("No Data Available")
                return
                
            # Store track length
            self.track_length = track_length
            display_range_max = track_length if track_length > 0 else 1000
                
            # Extract the telemetry points
            points = lap_data.get('points', [])
            if not points:
                logger.warning("No telemetry points found in lap data")
                self.display_message("No Telemetry Points")
                return
                
            # Process the data points to get distance and speed values
            distances = []
            speeds = []
            max_speed = 0
            
            for point in points:
                # Check required data keys
                if 'LapDist' not in point:
                    continue
                    
                # Get distance value
                dist = point['LapDist']
                
                # Get speed value and convert to km/h if needed
                speed = point.get('Speed', point.get('speed', 0))
                if isinstance(speed, (int, float)):
                    # Convert to km/h if speed is in m/s
                    if speed < 100:  # Assuming speeds < 100 are in m/s
                        speed *= 3.6
                    
                    max_speed = max(max_speed, speed)
                
                distances.append(dist)
                speeds.append(speed)
                
            if not distances:
                logger.warning("No valid distances extracted from telemetry points")
                self.display_message("Invalid Telemetry Data")
                return
                
            # Determine max distance for display range
            max_distance = max(distances) if distances else 0
            display_range_max = max(track_length, max_distance * 1.05, 1000)

            # Temporarily enable auto-range to allow programmatic updates
            self.plot_widget.plotItem.vb.enableAutoRange()
            
            # Update existing main curves using setData
            self.speed_curve.setData(distances, speeds)
            self.speed_curve.show()

            # Set the view ranges programmatically
            # Set appropriate Y range with some padding
            y_max = max(max_speed * 1.1, 300)  # Use at least 300 km/h as maximum
            self.plot_widget.setYRange(0, y_max, padding=0.02)
            self.plot_widget.setXRange(0, display_range_max, padding=0)

            # Disable auto-ranging again immediately after setting ranges
            self.plot_widget.plotItem.vb.disableAutoRange()
            
            # Detect and add stopped section markers
            stopped_sections = self._detect_stopped_sections(distances, speeds)
            for pos, data in stopped_sections:
                self.add_stopped_section_marker(pos, data)

            # Add track context if provided
            self._add_track_context_markers(track_context, display_range_max)
            
            # Ensure grid is visible
            self.plot_widget.showGrid(x=True, y=True, alpha=0.3)
            
            # Update title for single lap view
            self.plot_widget.setTitle("Speed vs Distance")
            
        except Exception as e:
            logger.error(f"Error updating speed graph: {e}")
            import traceback
            logger.error(traceback.format_exc())
            self.speed_curve.setData([], [])
            self.display_message("Graph Update Error")
            self.reset_view()

    def display_message(self, message):
        """Display a message on the graph when no data is available.
        
        Args:
            message: Message to display
        """
        # Clear any existing data
        self.speed_curve.setData([], [])
        
        # Add a text item to the center of the plot
        if not hasattr(self, 'message_text') or self.message_text is None:
            self.message_text = pg.TextItem(
                text=message,
                color=(200, 200, 200),
                anchor=(0.5, 0.5),
                fill=(0, 0, 0, 100)
            )
            self.plot_widget.addItem(self.message_text)
        else:
            self.message_text.setText(message)
            self.message_text.setVisible(True)
        
        # Position text in center
        view_range = self.plot_widget.viewRange()
        x_center = (view_range[0][0] + view_range[0][1]) / 2
        y_center = (view_range[1][0] + view_range[1][1]) / 2
        self.message_text.setPos(x_center, y_center)
        
        # Make sure the plot still has a reasonable display range
        self.reset_view() 