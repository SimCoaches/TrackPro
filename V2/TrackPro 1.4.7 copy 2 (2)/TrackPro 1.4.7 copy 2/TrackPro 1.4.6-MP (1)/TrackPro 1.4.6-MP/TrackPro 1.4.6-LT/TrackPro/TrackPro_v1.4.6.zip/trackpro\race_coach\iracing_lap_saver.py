"""
Module for saving iRacing lap times and telemetry data to Supabase.
"""

import os
import time
import logging
import uuid
import json
from datetime import datetime
from pathlib import Path

# Import the Supabase singleton client instead of creating a new one
from ..database.supabase_client import supabase

# Setup logging
logger = logging.getLogger(__name__)

class IRacingLapSaver:
    """
    Manages saving iRacing lap times and telemetry data to Supabase.
    """
    def __init__(self):
        """Initialize the lap saver with Supabase connection details."""
        self._supabase = None
        self._user_id = None
        self._connection_disabled = False  # Flag to track if Supabase operations should be completely disabled
        
        # Session tracking
        self._current_session_id = None
        self._current_track_id = None
        self._current_car_id = None
        self._current_session_type = None
        
        # Lap tracking
        self._current_lap_number = 0
        self._lap_start_time = 0
        self._last_track_position = 0
        self._is_first_telemetry = True
        self._current_lap_data = []
        self._current_lap_id = None
        self._best_lap_time = float('inf')
        
        # Enhanced lap detection
        self._recent_positions = []
        self._recent_timestamps = []
        self._position_buffer_size = 5  # Store last 5 positions
        self._min_lap_time = 20  # Minimum reasonable lap time in seconds to prevent false detections
        self._last_lap_end_time = 0
        self._track_coverage_threshold = 0.8  # 80% track coverage required for valid lap
        
        # Diagnostic settings
        self._diagnostic_mode = False
        self._position_log_file = None
        
    def set_supabase_client(self, client):
        """Set the Supabase client instance."""
        self._supabase = client
        if client:
            logger.info(f"Supabase client set for IRacingLapSaver: {client is not None}")
            self._connection_disabled = False
            
            # Test connection immediately to verify it's working
            try:
                if hasattr(client, 'table'):
                    # Try a simple query to verify the connection works
                    test_result = client.table('tracks').select('id').limit(1).execute()
                    if hasattr(test_result, 'data'):
                        logger.info(f"Supabase connection test successful: Got {len(test_result.data)} tracks")
                    else:
                        logger.warning("Supabase connection test returned no data attribute")
                else:
                    logger.warning("Supabase client has no 'table' method")
            except Exception as e:
                logger.error(f"Supabase connection test failed: {e}")
                
        else:
            logger.warning("Supabase client removed or not set - client is None")
            self._connection_disabled = True

        # Fallback: if no client provided, try to get from global singleton
        if not self._supabase:
            try:
                # Import here to avoid circular imports
                from ..database.supabase_client import supabase as global_client
                if global_client:
                    logger.info("Using global Supabase client instance as fallback")
                    self._supabase = global_client
                    self._connection_disabled = False
                    return
            except Exception as e:
                logger.error(f"Error getting global Supabase client: {e}")
                self._connection_disabled = True

    def set_user_id(self, user_id):
        """Set the current user ID for associating data."""
        self._user_id = user_id
        logger.info(f"Set user ID to: {user_id}")
        
    def enable_diagnostics(self, enabled=True):
        """Enable detailed diagnostic mode for troubleshooting."""
        self._diagnostic_mode = enabled
        if enabled:
            logger.setLevel(logging.DEBUG)
            # Create a diagnostic log file in user's documents
            docs_path = Path(os.path.expanduser("~/Documents/TrackPro/Diagnostics"))
            docs_path.mkdir(parents=True, exist_ok=True)
            
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            log_file = docs_path / f"lap_diagnostics_{timestamp}.log"
            
            file_handler = logging.FileHandler(str(log_file), mode='w')
            file_handler.setLevel(logging.DEBUG)
            formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
            file_handler.setFormatter(formatter)
            logger.addHandler(file_handler)
            
            logger.info(f"Diagnostic logging enabled to {log_file}")
            
            # Create CSV file for detailed position tracking
            self._position_log_file = docs_path / f"position_log_{timestamp}.csv"
            with open(self._position_log_file, 'w') as f:
                f.write("timestamp,session_time,lap_dist_pct,lap_number,lap_state\n")
            
            logger.info(f"Position log enabled to {self._position_log_file}")
        else:
            logger.setLevel(logging.INFO)
            self._position_log_file = None
            logger.info("Diagnostic logging disabled")

    def process_telemetry(self, telemetry_data):
        """Process incoming telemetry data to detect laps and save telemetry.
        
        Args:
            telemetry_data: A dictionary containing telemetry values.
            
        Returns:
            A tuple (is_new_lap, lap_number, lap_time) if a lap is completed,
            None otherwise.
        """
        # Increment debug counter
        if not hasattr(self, '_telemetry_debug_counter'):
            self._telemetry_debug_counter = 0
        self._telemetry_debug_counter += 1
        
        # Skip all Supabase operations if connection is disabled
        if self._connection_disabled:
            # Only log periodically to avoid spam
            if self._telemetry_debug_counter % 300 == 0:
                logger.warning("Supabase connection is disabled, skipping telemetry processing")
            return None
        
        # Ensure we have a session ID from the monitor
        if not self._current_session_id:
            # Log periodically if no session is active
            if self._telemetry_debug_counter % 300 == 0:
                logger.debug("Cannot process telemetry: No active session set by monitor.")
            return None

        # --- Enhanced Lap Detection Logic ---
        try:
            lap_dist_pct = telemetry_data.get('LapDistPct', -1)
            session_time = telemetry_data.get('SessionTimeSecs', 0)
            current_lap = telemetry_data.get('Lap', 0)
            
            # DEBUG: Log key telemetry values every ~5 seconds
            if self._telemetry_debug_counter % 300 == 0:
                logger.info(f"Lap Detection Debug: LapDistPct={lap_dist_pct:.3f}, Last={self._last_track_position:.3f}, Lap={current_lap}, SessionTime={session_time:.3f}")

            if lap_dist_pct < 0:
                if self._telemetry_debug_counter % 300 == 0:
                    logger.warning(f"Invalid track position: {lap_dist_pct}")
                return None # Invalid track position

            # Diagnostic position logging
            if self._diagnostic_mode and self._position_log_file:
                try:
                    with open(self._position_log_file, 'a') as f:
                        real_time = time.time()
                        lap_state = "START" if self._is_first_telemetry else "NORMAL"
                        f.write(f"{real_time},{session_time},{lap_dist_pct},{current_lap},{lap_state}\n")
                except Exception as e:
                    logger.error(f"Error writing to position log: {e}")
                    
            # Handle initial telemetry point
            if self._is_first_telemetry:
                self._last_track_position = lap_dist_pct
                self._lap_start_time = session_time
                self._current_lap_number = current_lap
                self._is_first_telemetry = False
                self._current_lap_data = []
                logger.info(f"Lap Saver: First telemetry received for Lap {self._current_lap_number}. Session: {self._current_session_id}")

            # Add to position history buffer for enhanced detection
            self._recent_positions.append(lap_dist_pct)
            self._recent_timestamps.append(session_time)
            if len(self._recent_positions) > self._position_buffer_size:
                self._recent_positions.pop(0)
                self._recent_timestamps.pop(0)
            
            # Enhanced crossing detection with multiple confirmations
            is_new_lap = False
            lap_time = 0
            completed_lap_number = self._current_lap_number
            
            # Three conditions for a valid lap crossing:
            # 1. We were recently in the final section (>0.9)
            # 2. We are now in the beginning section (<0.1)
            # 3. Multiple recent points confirm we're actually at the start of track
            # 4. Minimum time since last lap detection has passed
            
            have_recent_end = any(pos > 0.9 for pos in self._recent_positions[:-2])
            now_at_start = all(pos < 0.1 for pos in self._recent_positions[-2:]) if len(self._recent_positions) >= 2 else False
            min_time_passed = (session_time - self._last_lap_end_time) > self._min_lap_time
            
            # Log near S/F line for debugging
            if self._last_track_position > 0.85 or lap_dist_pct < 0.15:
                if self._telemetry_debug_counter % 60 == 0:  # Log more frequently near the line
                    logger.debug(f"Near S/F Line: Last={self._last_track_position:.3f}, Current={lap_dist_pct:.3f}, RecentEnd={have_recent_end}, AtStart={now_at_start}, MinTimePassed={min_time_passed}")
                    
                    # Update diagnostic log if in diagnostic mode
                    if self._diagnostic_mode and self._position_log_file:
                        try:
                            with open(self._position_log_file, 'a') as f:
                                f.write(f"{time.time()},{session_time},{lap_dist_pct},{current_lap},NEAR_SF\n")
                        except Exception as e:
                            logger.error(f"Error writing to position log: {e}")
            
            if have_recent_end and now_at_start and min_time_passed:
                is_new_lap = True
                lap_time = session_time - self._lap_start_time
                self._last_lap_end_time = session_time
                
                logger.info(f"Lap crossing detected: Position transition {self._recent_positions}, Time: {lap_time:.3f}s")
                
                # Update diagnostic log for lap crossing
                if self._diagnostic_mode and self._position_log_file:
                    try:
                        with open(self._position_log_file, 'a') as f:
                            f.write(f"{time.time()},{session_time},{lap_dist_pct},{current_lap},CROSSING\n")
                    except Exception as e:
                        logger.error(f"Error writing to position log: {e}")
                
                # Use iRacing's Lap value if available and seems correct
                iracing_reported_lap = telemetry_data.get('LapCompleted', completed_lap_number) # Use LapCompleted if exists
                if iracing_reported_lap >= completed_lap_number:
                    completed_lap_number = iracing_reported_lap
                    logger.info(f"Lap Saver: Using iRacing reported completed lap number: {completed_lap_number}")
                else:
                    logger.warning(f"Lap Saver: iRacing reported lap ({iracing_reported_lap}) is less than internal count ({completed_lap_number}). Using internal count.")
        
                # Get official lap time if available
                official_lap_time = telemetry_data.get('LapLastLapTime', 0)
                if official_lap_time > 0:
                    logger.info(f"Lap Saver: Using iRacing reported last lap time: {official_lap_time:.3f}s (vs calculated: {lap_time:.3f}s)")
                    lap_time = official_lap_time

            # Create a clean copy with all necessary fields
            # Ensure all essential fields are present with defaults
            clean_point = {
                "timestamp": telemetry_data.get('SessionTimeSecs', 0),
                "track_position": lap_dist_pct,
                "speed": telemetry_data.get('Speed', 0),
                "rpm": telemetry_data.get('RPM', 0),
                "gear": telemetry_data.get('Gear', 0),
                "throttle": telemetry_data.get('Throttle', 0),
                "brake": telemetry_data.get('Brake', 0),
                "clutch": telemetry_data.get('Clutch', 0),
                "steering": telemetry_data.get('SteeringWheelAngle', 0),
                "lat_accel": telemetry_data.get('LatAccel', 0),
                "long_accel": telemetry_data.get('LongAccel', 0),
            }
            
            # Only add point if it's different enough from the last one
            # to avoid wasting storage on nearly identical points
            add_point = True
            
            # REMOVED POINT FILTERING CODE HERE TO CAPTURE ALL POINTS
            # Original code was skipping points with similar position/inputs
            # This was reducing the data collection rate
            
            if add_point:
                self._current_lap_data.append(clean_point)
        
            # Update last position
            self._last_track_position = lap_dist_pct

            if is_new_lap and lap_time > 0:
                # Save the completed lap data
                saved_lap_id = self._save_lap_data(completed_lap_number, lap_time)

                # Start the next lap
                self._current_lap_number = current_lap # Use iRacing's current lap number
                self._lap_start_time = session_time
                self._current_lap_data = [] # Clear data for the new lap
                self._current_lap_id = saved_lap_id # Store the ID of the lap just saved
                logger.info(f"Lap Saver: Starting Lap {self._current_lap_number}")

                return True, completed_lap_number, lap_time

        except Exception as e:
            logger.error(f"Error processing telemetry: {e}", exc_info=True)

        return None # No new lap completed
        
    def _calculate_track_coverage(self, lap_data):
        """Calculate the percentage of track covered by the data points."""
        if not lap_data:
            return 0.0
            
        # Extract track positions
        positions = [point.get('track_position', 0) for point in lap_data]
        
        # Calculate coverage by dividing track into 100 segments and checking presence
        segments = [0] * 100
        for pos in positions:
            segment = min(99, max(0, int(pos * 100)))
            segments[segment] = 1
        
        coverage = sum(segments) / 100.0
        return coverage
        
    def _validate_lap_data(self, lap_data):
        """Validate lap data for completeness and quality."""
        if not lap_data:
            return False, "No lap data collected"
            
        # Check number of data points
        if len(lap_data) < 50:  # Arbitrary minimum
            return False, f"Too few data points: {len(lap_data)}"
        
        # Check track coverage
        coverage = self._calculate_track_coverage(lap_data)
        
        if coverage < self._track_coverage_threshold:
            return False, f"Insufficient track coverage: {coverage:.2f}"
        
        # Check for reasonable speed values
        speeds = [point.get("speed", 0) for point in lap_data]
        if not speeds or max(speeds) <= 0:
            return False, "No valid speed data"
        
        return True, f"Valid lap with {len(lap_data)} points, {coverage:.2f} coverage"

    def _save_lap_data(self, lap_number, lap_time):
        """Save lap data to Supabase with retry capability."""
        # Debug connection state
        logger.info(f"Attempting to save lap {lap_number} (time: {lap_time:.3f}s)")
        logger.info(f"Connection state: Supabase client exists: {self._supabase is not None}, Session ID: {self._current_session_id}")
        
        # First check: is connection disabled flag set?
        if self._connection_disabled:
            logger.error("Cannot save lap: connection is explicitly disabled")
            return None
        
        # Check if we have a Supabase client
        logger.debug(f"[SAVE_DEBUG] Checking self._supabase. Value: {self._supabase}, Type: {type(self._supabase)}")
        if not self._supabase:
            logger.error("Cannot save lap: No Supabase client available")
            
            # Try to get the global client as a fallback
            try:
                from ..database.supabase_client import supabase as global_client
                logger.debug(f"[SAVE_DEBUG] Fallback: Got global_client. Value: {global_client}, Type: {type(global_client)}")
                if global_client:
                    logger.info("Attempting to use global Supabase client for lap save")
                    self._supabase = global_client
                    logger.debug(f"[SAVE_DEBUG] Fallback: Set self._supabase. Value: {self._supabase}, Type: {type(self._supabase)}")
                    if not self._supabase:
                        logger.error("Global client retrieval failed")
                        return None
                else:
                    logger.error("Global Supabase client not available")
                    return None
            except Exception as e:
                logger.error(f"Error getting global Supabase client: {e}")
                self._connection_disabled = True

        # Check if we have a session ID
        if not self._current_session_id:
            logger.error(f"Cannot save lap: No session ID available")
            return None

        # Check if we have a user ID
        if not self._user_id:
            logger.error("Cannot save lap data: User ID not set")
            return None

        # Debug client capabilities
        logger.debug(f"[SAVE_DEBUG] Checking capabilities of self._supabase. Value: {self._supabase}, Type: {type(self._supabase)}")
        if hasattr(self._supabase, 'table'):
            logger.info("Supabase client has 'table' method")
        else:
            logger.error("Supabase client missing 'table' method - cannot save")
            return None

        # Validate lap data before saving
        is_valid, validation_message = self._validate_lap_data(self._current_lap_data)
        logger.info(f"Lap {lap_number} validation: {validation_message}")

        # Prepare lap data
        is_personal_best = lap_time < self._best_lap_time
        if is_personal_best and is_valid:
            self._best_lap_time = lap_time
        
        lap_data = {
            "session_id": self._current_session_id,
            "lap_number": lap_number,
            "lap_time": lap_time,
            "is_valid": is_valid, # Now based on validation
            "is_personal_best": is_personal_best and is_valid, # Only consider valid laps
            "user_id": self._user_id, # Include user_id directly
            "metadata": json.dumps({
                 "track_db_id": self._current_track_id,
                 "car_db_id": self._current_car_id,
                 "session_type": self._current_session_type,
                 "validation_message": validation_message,  # Store validation info
                 "point_count": len(self._current_lap_data),
                 "track_coverage": self._calculate_track_coverage(self._current_lap_data)
            })
        }
        
        # Make the save attempt
        try:
            logger.info(f"Saving Lap {lap_number} ({lap_time:.3f}s) for session {self._current_session_id}")
            response = self._supabase.table("laps").insert(lap_data).execute()
                
            if response.data and response.data[0].get('id'):
                saved_lap_uuid = response.data[0]['id']
                logger.info(f"Successfully saved lap {lap_number} (UUID: {saved_lap_uuid})")
                    
                # Save associated telemetry points
                if self._current_lap_data:
                    self._save_telemetry_points(saved_lap_uuid, self._current_lap_data)

                return saved_lap_uuid
            else:
                logger.error(f"Failed to save lap {lap_number}. Response: {response}")
        except Exception as e:
            logger.error(f"Error saving lap {lap_number}: {e}", exc_info=True)
            return None

    def _save_telemetry_points(self, lap_uuid, telemetry_points):
        if not self._supabase or not lap_uuid or not telemetry_points:
            logger.warning("Cannot save telemetry: Missing Supabase client, lap ID, or telemetry data.")
            return False
    
        logger.info(f"Saving {len(telemetry_points)} telemetry points for lap {lap_uuid}")
        batch_size = 100  # Reduced from 500 to allow faster processing of smaller batches
        saved_count = 0
        failed_count = 0
        failed_batch_indices = []  # Track which batches failed
        
        # First ensure points are sorted by track position for consistency
        sorted_points = sorted(telemetry_points, key=lambda x: x.get('track_position', 0))
        
        # Then process in batches
        for i in range(0, len(sorted_points), batch_size):
            batch = sorted_points[i:i + batch_size]
            telemetry_data_to_insert = []
            
            for point in batch:
                # Extract key fields, ensuring defaults if missing
                telemetry_data_to_insert.append({
                    "lap_id": lap_uuid,
                    "user_id": self._user_id,
                    "timestamp": point.get('timestamp', 0),
                    "track_position": point.get('track_position', 0),
                    "speed": point.get('speed', 0),
                    "rpm": point.get('rpm', 0),
                    "gear": point.get('gear', 0),
                    "throttle": point.get('throttle', 0),
                    "brake": point.get('brake', 0),
                    "clutch": point.get('clutch', 0),
                    "steering": point.get('steering', 0),
                    "lat_accel": point.get('lat_accel', 0),
                    "long_accel": point.get('long_accel', 0),
                    "batch_index": i // batch_size  # Store batch index for debugging
                })
                
            # Retry logic for batch saving
            max_retries = 3
            for retry in range(max_retries):
                try:
                    response = self._supabase.table("telemetry_points").insert(telemetry_data_to_insert).execute()
                    if response.data:
                        saved_count += len(response.data)
                        break  # Success
                    else:
                        logger.warning(f"Batch {i // batch_size} save attempt {retry+1} returned no data")
                        if retry == max_retries - 1:
                            failed_count += len(telemetry_data_to_insert)
                            failed_batch_indices.append(i // batch_size)
                except Exception as e:
                    logger.error(f"Error saving batch {i // batch_size}, attempt {retry+1}: {e}")
                    if retry == max_retries - 1:
                        failed_count += len(telemetry_data_to_insert)
                        failed_batch_indices.append(i // batch_size)
        
        success = failed_count == 0
        logger.info(f"Telemetry saving complete: Saved: {saved_count}, Failed: {failed_count}, Success: {success}")
        
        # If some batches failed, update the lap record to mark it as potentially incomplete
        if failed_count > 0:
            try:
                self._supabase.table("laps").update({
                    "metadata": json.dumps({
                        "telemetry_incomplete": True,
                        "failed_batches": failed_batch_indices,
                        "points_saved": saved_count,
                        "points_failed": failed_count
                    })
                }).eq("id", lap_uuid).execute()
                logger.warning(f"Marked lap {lap_uuid} as having incomplete telemetry")
            except Exception as e:
                logger.error(f"Error updating lap record for incomplete telemetry: {e}")
        
        return success

    def get_lap_times(self, session_id=None):
        """
        Get all lap times for a session.
        
        Args:
            session_id: The session ID (defaults to current session)
            
        Returns:
            List of lap time data
        """
        if not self._supabase:
            logger.error("Cannot get lap times: Supabase connection not available")
            return []
        
        session_id = session_id or self._current_session_id
        if not session_id:
            logger.error("Cannot get lap times: No session ID specified")
            return []
        
        try:
            result = self._supabase.table("laps").select("*").eq("session_id", session_id).order("lap_number").execute()
            
            if result.data:
                return result.data
            return []
            
        except Exception as e:
            logger.error(f"Error getting lap times: {e}")
            return []

    def get_telemetry_data(self, lap_id):
        """
        Get telemetry data for a specific lap.
        
        Args:
            lap_id: The lap ID
            
        Returns:
            List of telemetry data points
        """
        if not self._supabase:
            logger.error("Cannot get telemetry data: Supabase connection not available")
            return []
        
        try:
            result = self._supabase.table("telemetry_points").select("*").eq("lap_id", lap_id).order("track_position").execute()
            
            if result.data:
                return result.data
            return []
            
        except Exception as e:
            logger.error(f"Error getting telemetry data: {e}")
            return []

    def test_connection(self):
        """Test the Supabase connection and return diagnostic information."""
        result = {
            "connection_status": "unknown",
            "env_vars_set": {},
            "connected": False,
            "tables_accessible": {},
            "errors": []
        }
        
        # Check Supabase client exists
        if not self._supabase:
            result["connection_status"] = "failed"
            result["errors"].append("Supabase client not initialized")
            return result
        
        # Try to connect to Supabase
        try:
            # Test connection (no need to call _connect_to_supabase again)
            result["connected"] = True
            
            # Test database access by checking if tables exist
            tables_to_check = ["tracks", "cars", "sessions", "laps", "telemetry_points"]
            for table in tables_to_check:
                try:
                    response = self._supabase.table(table).select("id").limit(1).execute()
                    result["tables_accessible"][table] = {
                        "accessible": True,
                        "count": len(response.data) if hasattr(response, 'data') else 0
                    }
                except Exception as e:
                    result["tables_accessible"][table] = {
                        "accessible": False,
                        "error": str(e)
                    }
                    result["errors"].append(f"Failed to access table {table}: {e}")
            result["connection_status"] = "success" if not result["errors"] else "partial_success"
            
        except Exception as e:
            result["connection_status"] = "failed"
            result["errors"].append(f"General connection error: {e}")
            result["connected"] = False

            return result 