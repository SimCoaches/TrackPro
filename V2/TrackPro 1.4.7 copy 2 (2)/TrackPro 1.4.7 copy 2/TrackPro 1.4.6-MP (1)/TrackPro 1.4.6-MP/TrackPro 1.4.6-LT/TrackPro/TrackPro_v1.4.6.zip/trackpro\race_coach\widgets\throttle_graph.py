from PyQt5.QtWidgets import QWidget, QVBoxLayout
from PyQt5.QtCore import Qt
import pyqtgraph as pg
import numpy as np
import logging

logger = logging.getLogger(__name__)

class ThrottleGraphWidget(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        
        # Create the plot widget
        self.plot_widget = pg.PlotWidget()
        self.plot_widget.setBackground('k')  # Black background
        self.plot_widget.setTitle("Throttle vs Distance") 
        self.plot_widget.setLabel('bottom', "Distance (m)")
        
        # Configure Left Y-Axis for Percentage
        left_axis = self.plot_widget.getAxis('left')
        left_axis.setLabel("Throttle (%)")
        left_axis.setTicks([[(0, '0'), (0.25, '25'), (0.5, '50'), (0.75, '75'), (1.0, '100')]])
        
        # Show grid lines for both axes
        self.plot_widget.showGrid(x=True, y=True, alpha=0.3)
        
        # Disable mouse interaction for zoom/pan
        self.plot_widget.plotItem.vb.setMouseEnabled(x=False, y=False)
        self.plot_widget.setMenuEnabled(False)
        self.plot_widget.plotItem.vb.disableAutoRange()
        
        # Create a standard legend in the top-right corner with default style
        self.legend = self.plot_widget.addLegend(offset=(-20, 10), labelTextSize='10pt')
        
        # Create crosshair lines
        self.vLine = pg.InfiniteLine(angle=90, movable=False, pen=pg.mkPen('w', width=1))
        self.hLine = pg.InfiniteLine(angle=0, movable=False, pen=pg.mkPen('w', width=1))
        self.plot_widget.addItem(self.vLine, ignoreBounds=True)
        self.plot_widget.addItem(self.hLine, ignoreBounds=True)
        
        # Create text label for coordinates
        self.label = pg.TextItem(text='', color='w', anchor=(0, 1))
        self.label.setPos(10, 10)
        self.plot_widget.addItem(self.label, ignoreBounds=True)
        
        # Track context elements
        self.start_finish_line = pg.InfiniteLine(
            angle=90, 
            movable=False, 
            pen=pg.mkPen('y', width=2, style=Qt.DashLine),
            label="Start/Finish", 
            labelOpts={'position': 0.9, 'color': 'y'}
        )
        self.plot_widget.addItem(self.start_finish_line, ignoreBounds=True)
        self.start_finish_line.hide()  # Hide initially
        
        # Container for corner and distance markers
        self.corner_markers = []
        self.distance_markers = []
        self.stopped_section_markers = []
        
        # Track parameters
        self.track_length = 0
        
        # Connect mouse movement for crosshair
        self.plot_widget.scene().sigMouseMoved.connect(self.mouseMoved)
        
        # Setup layout
        layout = QVBoxLayout()
        layout.addWidget(self.plot_widget)
        self.setLayout(layout)
        
        # Initialize plot items - these will be updated by update_graph/update_comparison_data
        self.throttle_curve = self.plot_widget.plot(pen=pg.mkPen('#00C800', width=2), name="Lap A Throttle", autoDownsample=False, clipToView=False)
        self.throttle_curve_b = self.plot_widget.plot(pen=pg.mkPen('#88FF88', width=2, style=Qt.SolidLine), name="Lap B Throttle", autoDownsample=False, clipToView=False)
        
        # Initially hide comparison curves
        self.throttle_curve_b.hide()
        
        # Initialize empty data list for plot items (no longer used directly for curves)
        self.plot_items = [] 
        
        # Store message text item reference
        self.message_text = None
        
        self.comparison_mode = False # Initialize comparison mode
        
        self.reset_view()
        
    def mouseMoved(self, pos):
        """Handle mouse movement to update crosshairs and tooltip."""
        if self.plot_widget.sceneBoundingRect().contains(pos):
            mousePoint = self.plot_widget.plotItem.vb.mapSceneToView(pos)
            x, y = mousePoint.x(), mousePoint.y()
            
            # Update crosshair positions
            self.vLine.setPos(x)
            self.hLine.setPos(y)
            
            # Find the actual throttle values at the cursor position
            throttle_value_a = None
            throttle_value_b = None
            distance = x
            
            # Find the closest data point from Lap A
            if self.throttle_curve.xData is not None and len(self.throttle_curve.xData) > 0:
                # Find the closest x point to the cursor
                closest_idx = -1
                min_distance = float('inf')
                
                for i, x_val in enumerate(self.throttle_curve.xData):
                    dist = abs(x_val - x)
                    if dist < min_distance:
                        min_distance = dist
                        closest_idx = i
                
                if closest_idx >= 0:
                    # Get actual throttle value from the data
                    if closest_idx < len(self.throttle_curve.yData):
                        throttle_value_a = self.throttle_curve.yData[closest_idx] * 100  # Convert to percentage

            # In comparison mode, also get data from Lap B
            if self.comparison_mode and self.throttle_curve_b.xData is not None and len(self.throttle_curve_b.xData) > 0:
                # Find the closest x point to the cursor
                closest_idx = -1
                min_distance = float('inf')
                
                for i, x_val in enumerate(self.throttle_curve_b.xData):
                    dist = abs(x_val - x)
                    if dist < min_distance:
                        min_distance = dist
                        closest_idx = i
                
                if closest_idx >= 0:
                    # Get actual throttle value from the data
                    if closest_idx < len(self.throttle_curve_b.yData):
                        throttle_value_b = self.throttle_curve_b.yData[closest_idx] * 100  # Convert to percentage
            
            # Format tooltip text with the actual values
            if throttle_value_a is not None:
                # Basic tooltip for single lap
                if not self.comparison_mode or throttle_value_b is None:
                    tooltip = f"""
                        <div style='background-color: rgba(0, 0, 0, 180); padding: 4px;'>
                            <span style='color: white;'>Dist: {distance:.1f}m</span> &nbsp;
                            <span style='color: #00FF00;'>Throttle: {throttle_value_a:.0f}%</span>
                        </div>
                    """
                else:
                    # Enhanced tooltip for comparison
                    tooltip = f"""
                        <div style='background-color: rgba(0, 0, 0, 180); padding: 4px;'>
                            <span style='color: white;'>Dist: {distance:.1f}m</span><br>
                            <span style='color: #00FF00;'>Lap A Throttle: {throttle_value_a:.0f}%</span> &nbsp;
                            <span style='color: #88FF88;'>Lap B Throttle: {throttle_value_b:.0f}%</span>
                        </div>
                    """
                
                # Check if hovering over a stopped section
                for marker in self.stopped_section_markers:
                    if hasattr(marker, 'stopped_data') and abs(x - marker.pos().x()) < 5:
                        section = marker.stopped_data
                        if not self.comparison_mode:
                            tooltip = f"""
                                <div style='background-color: rgba(0, 0, 0, 180); padding: 4px;'>
                                    <span style='color: white;'>Dist: {distance:.1f}m</span> &nbsp;
                                    <span style='color: #FF6666;'><b>Car Stopped</b></span> &nbsp;
                                    <span style='color: #00FF00;'>Throttle: {section['avg_throttle']*100:.0f}%</span>
                                </div>
                            """
                        break
                
                # Set tooltip position and content
                self.label.setHtml(tooltip)
                
                # Position the tooltip at the top of the graph where there's more space
                # Check if we're in the upper part of the graph
                if y > 0.5:
                    # If cursor is in top half, show tooltip below cursor
                    self.label.setPos(x, 0.2)
                else:
                    # If cursor is in bottom half, show tooltip above cursor
                    self.label.setPos(x, 0.8)

    def reset_view(self):
        """Reset the view to show the entire lap from start to finish."""
        try:
            # Temporarily enable auto-ranging
            self.plot_widget.plotItem.vb.enableAutoRange()

            # Set fixed Y range for inputs (0-100%)
            self.plot_widget.setYRange(0, 1, padding=0)
            
            # Set X range to track length if available, otherwise use a default
            if self.track_length and self.track_length > 0:
                self.plot_widget.setXRange(0, self.track_length, padding=0)
            else:
                self.plot_widget.setXRange(0, 1000, padding=0)

            # Disable auto-ranging again
            self.plot_widget.plotItem.vb.disableAutoRange()
        except Exception as e:
            print(f"Error in reset_view: {e}")
            # Ensure auto-range is disabled on error
            try:
                self.plot_widget.plotItem.vb.disableAutoRange()
            except Exception: # Handle potential nested errors
                pass

    def clear_track_markers(self):
        """Clear all track context markers from the graph."""
        # Hide start/finish line
        self.start_finish_line.hide()
        
        # Remove all corner markers
        for marker in self.corner_markers:
            self.plot_widget.removeItem(marker)
        self.corner_markers = []
        
        # Remove all distance markers
        for marker in self.distance_markers:
            self.plot_widget.removeItem(marker)
        self.distance_markers = []
        
        # Remove all stopped section markers
        for marker in self.stopped_section_markers:
            self.plot_widget.removeItem(marker)
        self.stopped_section_markers = []
        
    def add_start_finish_line(self, position=0.0):
        """Add or update start/finish line at the specified position."""
        self.start_finish_line.setPos(position)
        self.start_finish_line.show()
        
    def add_corner_marker(self, position, corner_number):
        """Add a corner marker at the specified position."""
        # Create corner marker as a vertical line with label
        corner_marker = pg.InfiniteLine(
            angle=90, 
            movable=False,
            pen=pg.mkPen('c', width=1, style=Qt.DotLine),
            label=f"C{corner_number}", 
            labelOpts={'position': 0.1, 'color': 'c', 'fill': (0, 0, 0, 100)}
        )
        corner_marker.setPos(position)
        self.plot_widget.addItem(corner_marker, ignoreBounds=True)
        self.corner_markers.append(corner_marker)
        
    def add_distance_marker(self, position, label=None):
        """Add a distance marker at the specified position."""
        # If no label provided, format position as distance
        if label is None:
            label = f"{int(position)}m"
            
        # Create distance marker as a vertical line with label
        distance_marker = pg.InfiniteLine(
            angle=90, 
            movable=False,
            pen=pg.mkPen('w', width=1, style=Qt.DotLine),
            label=label, 
            labelOpts={'position': 0.05, 'color': 'w', 'fill': (0, 0, 0, 100)}
        )
        distance_marker.setPos(position)
        self.plot_widget.addItem(distance_marker, ignoreBounds=True)
        self.distance_markers.append(distance_marker)
    
    def add_stopped_section_marker(self, position, data):
        """Add a marker for sections where the car appears to have stopped."""
        if position <= 0:
            return
            
        # Create an arrow marker at the position
        marker = pg.ArrowItem(pos=(position, 0), angle=-90, headLen=15, 
                             pen=None, brush='r', tailLen=None)
        marker.stopped_data = data  # Attach data for tooltip
        self.plot_widget.addItem(marker)
        self.stopped_section_markers.append(marker)
    
    def _detect_stopped_sections(self, distances, throttles, min_points_stop=10, pos_tolerance=0.5):
        """Detect sections where the car appears to have stopped based on distance data."""
        stopped_sections_output = []
        if not distances or len(distances) < min_points_stop:
            return stopped_sections_output

        pos_counts = {}
        point_data = {} # Store first point's data for each bin

        for i, dist in enumerate(distances):
            bin_pos = round(dist / pos_tolerance) * pos_tolerance
            pos_counts[bin_pos] = pos_counts.get(bin_pos, 0) + 1
            if bin_pos not in point_data:
                 # Store first point's data for tooltip
                 point_data[bin_pos] = {
                     'avg_throttle': throttles[i] if i < len(throttles) else 0,
                     'count': 0 # We'll update count later
                 }

        for pos, count in pos_counts.items():
            if count >= min_points_stop:
                # For the tooltip, add data about this stopped section
                section_data = point_data.get(pos, {'avg_throttle': 0})
                section_data['count'] = count # Add the count here
                stopped_sections_output.append((pos, section_data))

        return stopped_sections_output

    def _add_track_context_markers(self, track_context, track_length):
        """Helper method to add all track context markers."""
        # Add start/finish line
        start_finish_pos = track_context.get('start_finish', 0) if track_context else 0
        self.add_start_finish_line(start_finish_pos)

        if track_context:
            # Add corner markers
            if 'corners' in track_context:
                for corner_pos, corner_num in track_context['corners']:
                    self.add_corner_marker(corner_pos, corner_num)

            # Add distance markers (specific ones if provided)
            if 'markers' in track_context:
                 for marker in track_context['markers']:
                     if isinstance(marker, tuple):
                         self.add_distance_marker(marker[0], marker[1])
                     else:
                         self.add_distance_marker(marker)
            # Auto-generate distance markers if none provided and track_length is known
            elif track_length > 0:
                marker_interval = 500  # Default: every 500m
                if track_length > 10000: marker_interval = 2000 # Very Long
                elif track_length > 5000: marker_interval = 1000 # Long
                elif track_length > 2000: marker_interval = 500 # Medium (already set)
                else: marker_interval = 200 # Short

                for pos in range(marker_interval, int(track_length), marker_interval):
                    # Avoid placing marker too close to start/finish
                    if abs(pos - start_finish_pos) > marker_interval * 0.5:
                         self.add_distance_marker(pos)
        # Always add a marker at the very end if track length is known
        if track_length > 0:
             self.add_distance_marker(track_length, f"{int(track_length)}m")

    def update_graph_comparison(self, lap_a_data, lap_b_data, track_length, track_context=None):
        """Update the graph to display a comparison of two laps."""
        logger.info(f"Updating throttle graph with comparison data for A:{len(lap_a_data['points']) if lap_a_data else 'None'} and B:{len(lap_b_data['points']) if lap_b_data else 'None'} points")
        
        # Set comparison mode flag to True
        self.comparison_mode = True

        # --- COMPLETELY RESET PLOT STATE ---
        # Clear both curves by setting empty data arrays
        self.throttle_curve.setData([], [])
        self.throttle_curve_b.setData([], [])
        
        # Reset plot items and state
        if self.legend:
            self.legend.clear()
            
        # Clear all additional items from the plot that might be leftover
        for item in self.plot_widget.items():
            if item not in [self.throttle_curve, self.throttle_curve_b, self.vLine, self.hLine, self.label, self.start_finish_line]:
                self.plot_widget.removeItem(item)
                
        # Clear any message text
        if hasattr(self, 'message_text') and self.message_text and self.message_text in self.plot_widget.items():
             self.plot_widget.removeItem(self.message_text)
             self.message_text = None
             
        # Clear all track markers
        self.clear_track_markers()
        # --- END COMPLETE RESET ---

        # --- Ensure curves are visible and legend exists --- 
        self.throttle_curve.show()
        self.throttle_curve_b.show()
        if self.legend is None:
             # Create a new legend with proper styling if it doesn't exist
             self.legend = self.plot_widget.addLegend(offset=(-20, 10), labelTextSize='10pt')
        # ------------------------------------------------
        
        # Initialize variable for lap processing
        max_dist_overall = 0
        
        # --- Helper Function to Process Lap ---
        def process_lap(lap_dict):
            nonlocal max_dist_overall
            points = lap_dict.get('points', [])
            if not points: return None, None

            distances = []
            throttle_values = []

            for point in points:
                # Use 'LapDist' key for distance (expecting meters now)
                if 'LapDist' in point:
                    dist = point['LapDist']
                else: continue # Skip if missing distance

                throttle = point.get('Throttle', point.get('throttle', 0))
                distances.append(dist)
                throttle_values.append(throttle)

            if distances:
                max_dist_overall = max(max_dist_overall, max(distances))
                return distances, throttle_values
            return None, None
        # --- End Helper ---

        # Process main lap (Lap A)
        main_distances, main_throttles = process_lap(lap_a_data)
        if main_distances:
            self.throttle_curve.setData(main_distances, main_throttles)
            logger.info(f"Set Lap A throttle data with {len(main_distances)} points")
        else:
            logger.warning("No valid data for Lap A")
            self.throttle_curve.hide()

        # Process comparison lap (Lap B)
        comp_distances, comp_throttles = process_lap(lap_b_data)
        if comp_distances:
            self.throttle_curve_b.setData(comp_distances, comp_throttles)
            logger.info(f"Set Lap B throttle data with {len(comp_distances)} points")
        else:
            logger.warning("No valid data for Lap B")
            self.throttle_curve_b.hide() # Ensure hidden if no data

        # Ensure the legend is populated AFTER setting data
        if self.legend:
            self.legend.clear()  # Make sure to clear the legend again before adding items
            if main_distances:
                 self.legend.addItem(self.throttle_curve, "Lap A Throttle")
            if comp_distances:
                 self.legend.addItem(self.throttle_curve_b, "Lap B Throttle")

        # Determine track length
        self.track_length = 0
        track_context = lap_a_data.get('track_context') if lap_a_data else (lap_b_data.get('track_context') if lap_b_data else None)
        if lap_a_data and lap_a_data.get('track_length'): self.track_length = lap_a_data['track_length']
        elif lap_b_data and lap_b_data.get('track_length'): self.track_length = lap_b_data['track_length']
        display_range_max = self.track_length if self.track_length > 0 else max(max_dist_overall * 1.05, 1000)

        # Update title and axis ranges
        self.plot_widget.setTitle("Throttle vs Distance (Comparison)")
        self.plot_widget.setXRange(0, display_range_max, padding=0)
        self.plot_widget.setYRange(0, 1, padding=0.02)
        
        # Add track context markers (should be added after curves)
        self._add_track_context_markers(track_context, display_range_max)
        
        # Re-add crosshairs and labels as they might have been removed
        if self.vLine not in self.plot_widget.items(): self.plot_widget.addItem(self.vLine, ignoreBounds=True)
        if self.hLine not in self.plot_widget.items(): self.plot_widget.addItem(self.hLine, ignoreBounds=True)
        if self.label not in self.plot_widget.items(): self.plot_widget.addItem(self.label, ignoreBounds=True)
        
        # Add grid
        self.plot_widget.showGrid(x=True, y=True, alpha=0.3)
        
        # Force a redraw of the plot
        self.plot_widget.update()

    def update_graph(self, lap_data, track_length, track_context=None):
        """Update the graph with new lap data using distance as X-axis."""
        try:
            # Ensure comparison mode is off and comparison curves are hidden
            self.comparison_mode = False
            self.throttle_curve_b.hide()

            # Store track length for view resets
            self.track_length = track_length
            
            # Clear markers only
            self.clear_track_markers()
            
            # Hide message if it exists
            if self.message_text:
                self.message_text.setVisible(False)

            # Handle empty data case
            if not lap_data:
                self.throttle_curve.setData([], []) # Clear main curves
                self.display_message("No Lap Data")
                self.reset_view()
                return

            # Extract data from points
            try:
                # Use 'LapDist' key for distance (in meters)
                distances = [max(0, point["LapDist"]) for point in lap_data]
                throttles = [point["throttle"] for point in lap_data]
            except KeyError as key_err:
                print(f"Missing required data key: {key_err}. Available keys: {list(lap_data[0].keys()) if lap_data else 'No data'}")
                self.throttle_curve.setData([], [])
                self.display_message(f"Data Error: Missing {key_err}")
                self.reset_view()
                return

            if not distances:
                self.throttle_curve.setData([], [])
                self.display_message("No Distance Data")
                self.reset_view() 
                return
                
            # Calculate display range
            max_dist = max(distances)
            display_range_max = track_length if track_length and track_length > 0 else max(max_dist * 1.05, 1000)
                
            # Clamp input data to 0-1 range
            throttles_clamped = np.clip(throttles, 0, 1)

            # Temporarily enable auto-range to allow programmatic updates
            self.plot_widget.plotItem.vb.enableAutoRange()
            
            # Update existing main curves using setData
            self.throttle_curve.setData(distances, throttles_clamped)
            self.throttle_curve.show()

            # Set the view ranges programmatically
            self.plot_widget.setYRange(0, 1, padding=0.02) # Add slight padding
            self.plot_widget.setXRange(0, display_range_max, padding=0)

            # Disable auto-ranging again immediately after setting ranges
            self.plot_widget.plotItem.vb.disableAutoRange()
            
            # Detect and add stopped section markers
            stopped_sections = self._detect_stopped_sections(distances, throttles)
            for pos, data in stopped_sections:
                self.add_stopped_section_marker(pos, data)

            # Add track context if provided
            self._add_track_context_markers(track_context, display_range_max)
            
            # Ensure grid is visible
            self.plot_widget.showGrid(x=True, y=True, alpha=0.3)
            
            # Update title for single lap view
            self.plot_widget.setTitle("Throttle vs Distance")
            
        except Exception as e:
            print(f"Error updating graph: {e}")
            import traceback
            print(traceback.format_exc())
            self.throttle_curve.setData([], [])
            self.display_message("Graph Update Error")
            self.reset_view() 

    def display_message(self, message):
        """Display a message on the graph when no data is available.
        
        Args:
            message: Message to display
        """
        # Clear any existing data
        self.throttle_curve.setData([], [])
        
        # Add a text item to the center of the plot
        if not hasattr(self, 'message_text') or self.message_text is None:
            self.message_text = pg.TextItem(
                text=message,
                color=(200, 200, 200),
                anchor=(0.5, 0.5),
                fill=(0, 0, 0, 100)
            )
            self.plot_widget.addItem(self.message_text)
        else:
            self.message_text.setText(message)
            self.message_text.setVisible(True)
        
        # Position text in center
        view_range = self.plot_widget.viewRange()
        x_center = (view_range[0][0] + view_range[0][1]) / 2
        y_center = (view_range[1][0] + view_range[1][1]) / 2
        self.message_text.setPos(x_center, y_center)
        
        # Make sure the plot still has a reasonable display range
        self.reset_view() 