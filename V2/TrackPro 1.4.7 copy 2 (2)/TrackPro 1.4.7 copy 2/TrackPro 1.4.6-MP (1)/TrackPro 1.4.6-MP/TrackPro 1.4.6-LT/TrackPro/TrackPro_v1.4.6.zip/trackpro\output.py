import ctypes
from ctypes import wintypes
import logging
import time
import os
import winreg

logger = logging.getLogger(__name__)

# vJoy constants
HID_USAGE_X = 0x30
HID_USAGE_Y = 0x31
HID_USAGE_Z = 0x32
VJD_STAT_FREE = 0
VJD_STAT_OWN = 1
VJD_STAT_BUSY = 2
VJD_STAT_MISS = 3
AXIS_MIN = 0
AXIS_MAX = 65535

class JOYSTICK_POSITION_V2(ctypes.Structure):
    _fields_ = [
        ('bDevice', wintypes.BYTE),
        ('wThrottle', wintypes.LONG),
        ('wRudder', wintypes.LONG),
        ('wAileron', wintypes.LONG),
        ('wAxisX', wintypes.LONG),
        ('wAxisY', wintypes.LONG),
        ('wAxisZ', wintypes.LONG),
        ('wAxisXRot', wintypes.LONG),
        ('wAxisYRot', wintypes.LONG),
        ('wAxisZRot', wintypes.LONG),
        ('wSlider', wintypes.LONG),
        ('wDial', wintypes.LONG),
        ('wWheel', wintypes.LONG),
        ('wAxisVX', wintypes.LONG),
        ('wAxisVY', wintypes.LONG),
        ('wAxisVZ', wintypes.LONG),
        ('wAxisVBRX', wintypes.LONG),
        ('wAxisVBRY', wintypes.LONG),
        ('wAxisVBRZ', wintypes.LONG),
        ('lButtons', wintypes.LONG),
        ('bHats', wintypes.DWORD),
        ('bHatsEx1', wintypes.DWORD),
        ('bHatsEx2', wintypes.DWORD),
        ('bHatsEx3', wintypes.DWORD),
    ]

class VirtualJoystick:
    """Virtual joystick output using vJoy."""
    
    def __init__(self, test_mode=False, retry_count=3, use_alt_devices=True):
        """Initialize the virtual joystick.
        
        Args:
            test_mode (bool): If True, runs in test mode without actual vJoy output
            retry_count (int): Number of times to retry acquiring a vJoy device
            use_alt_devices (bool): If True, will try alternative vJoy device IDs if primary is busy
        """
        self.test_mode = test_mode
        
        if test_mode:
            logger.info("Running in test mode - virtual joystick simulation")
            self.vjoy_device_id = 1
            self.vjoy_acquired = True
            return
            
        # Try to set the device name
        try:
            # Set the device name to make it easier to identify in games
            import win32api
            import win32con
            
            # Open the registry key
            key_path = r"SYSTEM\CurrentControlSet\Control\MediaProperties\PrivateProperties\Joystick\OEM\VID_1234&PID_BEAD"
            try:
                key = win32api.RegOpenKeyEx(win32con.HKEY_LOCAL_MACHINE, key_path, 0, win32con.KEY_SET_VALUE)
                win32api.RegSetValueEx(key, "OEMName", 0, win32con.REG_SZ, "TrackPro Virtual Pedals")
                win32api.RegCloseKey(key)
                logger.info("Set vJoy device name to 'TrackPro Virtual Pedals'")
            except Exception as e:
                logger.error(f"Failed to set vJoy device name: {e}")
        except ImportError:
            logger.warning("win32api not available, skipping device name setting")
        
        # Load the vJoy DLL
        self.vjoy_dll = None
        # Try to load the vJoy DLL
        self.vjoy_dll = self._find_vjoy_dll()
        
        # Check if vJoy is enabled
        if not self.vjoy_dll.vJoyEnabled():
            raise RuntimeError("vJoy is not enabled")
            
        # Default device ID
        self.vjoy_device_id = 1
        self.vjoy_acquired = False
        
        # Try multiple device IDs if enabled
        device_ids_to_try = [1]  # Default device ID
        if use_alt_devices:
            # Add alternative device IDs to try
            device_ids_to_try.extend([2, 3, 4])
        
        # Try to acquire a vJoy device
        acquired = False
        last_error = None
        
        for device_id in device_ids_to_try:
            self.vjoy_device_id = device_id
            
            # Try multiple times to acquire this device ID
            for attempt in range(retry_count):
                try:
                    # Check if vJoy device exists
                    if not self.vjoy_dll.GetVJDStatus(device_id):
                        logger.warning(f"vJoy Device {device_id} does not exist")
                        continue
                    
                    # Get device status
                    status = self.vjoy_dll.GetVJDStatus(device_id)
                    
                    if status == 0:  # VJD_STAT_OWN
                        logger.info(f"vJoy Device {device_id} is already owned by this feeder")
                        self.vjoy_acquired = True
                        acquired = True
                        break
                    elif status == 1:  # VJD_STAT_FREE
                        if self.vjoy_dll.AcquireVJD(device_id):
                            logger.info(f"Acquired vJoy Device {device_id}")
                            self.vjoy_acquired = True
                            acquired = True
                            break
                        else:
                            last_error = f"Failed to acquire vJoy Device {device_id}"
                            logger.warning(last_error)
                    elif status == 2:  # VJD_STAT_BUSY
                        last_error = f"vJoy device {device_id} is already owned by another feeder"
                        logger.warning(last_error)
                        # Wait briefly before retrying
                        import time
                        time.sleep(0.5)
                    elif status == 3:  # VJD_STAT_MISS
                        last_error = f"vJoy device {device_id} is not installed or disabled"
                        logger.warning(last_error)
                        break  # No point retrying this device ID
                    else:
                        last_error = f"vJoy device {device_id} has unknown status: {status}"
                        logger.warning(last_error)
                except Exception as e:
                    last_error = f"Error with vJoy device {device_id}: {e}"
                    logger.warning(last_error)
            
            if acquired:
                break
        
        # If we couldn't acquire any device, raise the last error
        if not acquired:
            raise RuntimeError(last_error or "Failed to initialize vJoy: No devices available")
    
    def update_axis(self, throttle: int, brake: int, clutch: int):
        """Update the virtual joystick axes."""
        if self.test_mode:
            # In test mode, just log the values
            logger.debug(f"Test mode - Axis values: Throttle={throttle}, Brake={brake}, Clutch={clutch}")
            return True
            
        if not hasattr(self, 'vjoy_acquired') or not self.vjoy_acquired:
            logger.error("Cannot update axes: vJoy device not acquired")
            return False
            
        try:
            # Set X axis (throttle)
            self.vjoy_dll.SetAxis(throttle, self.vjoy_device_id, 0x30)  # HID_USAGE_X
            
            # Set Y axis (brake)
            self.vjoy_dll.SetAxis(brake, self.vjoy_device_id, 0x31)  # HID_USAGE_Y
            
            # Set Z axis (clutch)
            self.vjoy_dll.SetAxis(clutch, self.vjoy_device_id, 0x32)  # HID_USAGE_Z
            
            return True
        except Exception as e:
            logger.error(f"Failed to update vJoy axes: {e}")
            return False
    
    def __del__(self):
        """Clean up vJoy device."""
        try:
            if hasattr(self, 'vjoy_dll') and self.vjoy_dll:
                self.vjoy_dll.RelinquishVJD(self.vjoy_device_id)
                logger.info("vJoy device released")
        except Exception as e:
            logger.error(f"Error cleaning up vJoy device: {e}")

    def _find_vjoy_dll(self):
        """Find the vJoy DLL path."""
        import os
        import ctypes
        
        # Try to find the vJoy SDK DLL
        dll_paths = [
            r"C:\Program Files\vJoy\x64\vJoyInterface.dll",
            r"C:\Program Files (x86)\vJoy\x86\vJoyInterface.dll",
            os.path.join(os.path.dirname(os.path.abspath(__file__)), "vJoyInterface.dll"),
            os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "vJoyInterface.dll")
        ]
        
        for path in dll_paths:
            if os.path.exists(path):
                try:
                    logger.info(f"Found vJoy DLL at {path}")
                    vjoy_dll = ctypes.WinDLL(path)
                    
                    # Define function prototypes
                    vjoy_dll.vJoyEnabled.restype = ctypes.c_bool
                    vjoy_dll.vJoyEnabled.argtypes = []
                    
                    vjoy_dll.GetvJoyVersion.restype = ctypes.c_short
                    vjoy_dll.GetvJoyVersion.argtypes = []
                    
                    vjoy_dll.AcquireVJD.restype = ctypes.c_bool
                    vjoy_dll.AcquireVJD.argtypes = [ctypes.c_uint]
                    
                    vjoy_dll.GetVJDStatus.restype = ctypes.c_int
                    vjoy_dll.GetVJDStatus.argtypes = [ctypes.c_uint]
                    
                    vjoy_dll.SetAxis.restype = ctypes.c_bool
                    vjoy_dll.SetAxis.argtypes = [ctypes.c_long, ctypes.c_uint, ctypes.c_uint]
                    
                    vjoy_dll.RelinquishVJD.restype = ctypes.c_bool
                    vjoy_dll.RelinquishVJD.argtypes = [ctypes.c_uint]
                    
                    # Get vJoy version
                    version = vjoy_dll.GetvJoyVersion()
                    logger.info(f"vJoy Version: {version}")
                    
                    return vjoy_dll
                except Exception as e:
                    logger.warning(f"Error loading vJoy DLL from {path}: {e}")
        
        raise RuntimeError("vJoy DLL not found. Please make sure vJoy is installed correctly.") 