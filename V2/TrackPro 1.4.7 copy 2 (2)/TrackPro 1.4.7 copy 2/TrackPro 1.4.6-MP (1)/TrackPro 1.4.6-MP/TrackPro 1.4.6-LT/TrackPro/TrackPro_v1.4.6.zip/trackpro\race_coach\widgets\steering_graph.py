from PyQt5.QtWidgets import QWidget, QVBoxLayout
from PyQt5.QtCore import Qt
import pyqtgraph as pg
import numpy as np
import math
import logging

logger = logging.getLogger(__name__)

class SteeringGraphWidget(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        
        # Create the plot widget
        self.plot_widget = pg.PlotWidget()
        self.plot_widget.setBackground('k')  # Black background
        self.plot_widget.setTitle("Steering vs Distance")
        self.plot_widget.setLabel('bottom', "Distance (m)")
        
        # Configure Y-Axis for steering (-100% to 100%)
        left_axis = self.plot_widget.getAxis('left')
        left_axis.setLabel("Steering (%)")
        left_axis.setTicks([[(-1.0, '-100'), (-0.75, '-75'), (-0.5, '-50'), (-0.25, '-25'), 
                             (0, '0'), 
                             (0.25, '25'), (0.5, '50'), (0.75, '75'), (1.0, '100')]])
        
        # Show grid lines for both axes
        self.plot_widget.showGrid(x=True, y=True, alpha=0.3)
        
        # Disable mouse interaction
        self.plot_widget.plotItem.vb.setMouseEnabled(x=False, y=False)
        self.plot_widget.setMenuEnabled(False)
        self.plot_widget.plotItem.vb.disableAutoRange()
        
        # Create a standard legend in the top-right corner with default style
        self.legend = self.plot_widget.addLegend(offset=(-20, 10), labelTextSize='10pt')
        
        # Add horizontal line at 0
        self.zero_line = pg.InfiniteLine(angle=0, pos=0, pen=pg.mkPen('w', width=1, style=Qt.DashLine))
        self.plot_widget.addItem(self.zero_line)
        
        # Create crosshair lines
        self.vLine = pg.InfiniteLine(angle=90, movable=False, pen=pg.mkPen('w', width=1))
        self.hLine = pg.InfiniteLine(angle=0, movable=False, pen=pg.mkPen('w', width=1))
        self.plot_widget.addItem(self.vLine, ignoreBounds=True)
        self.plot_widget.addItem(self.hLine, ignoreBounds=True)
        
        # Create text label for coordinates
        self.label = pg.TextItem(text='', color='w', anchor=(0, 1))
        self.label.setPos(10, 10)
        self.plot_widget.addItem(self.label, ignoreBounds=True)
        
        # Store track markers
        self.track_markers = []
        self.track_length = 0
        
        # Connect mouse movement to crosshair update
        self.proxy = pg.SignalProxy(self.plot_widget.scene().sigMouseMoved, rateLimit=60, slot=self.mouseMoved)
        
        # Set up the layout
        layout = QVBoxLayout()
        layout.setContentsMargins(0, 0, 0, 0)
        layout.addWidget(self.plot_widget)
        self.setLayout(layout)
        
        # Initialize plot items - these will be updated by update_graph/update_comparison_data
        self.steering_curve = self.plot_widget.plot(pen=pg.mkPen('#00A0FF', width=2), name="Lap A Steering", autoDownsample=False, clipToView=False)
        self.steering_curve_b = self.plot_widget.plot(pen=pg.mkPen('#88D0FF', width=2, style=Qt.SolidLine), name="Lap B Steering", autoDownsample=False, clipToView=False)
        
        # Initially hide comparison curve
        self.steering_curve_b.hide()
        
        # Initialize empty plot items list (no longer used directly for curves)
        self.plot_items = []
        
        # Store message text item reference
        self.message_text = None
        
        self.comparison_mode = False # Initialize comparison mode
        
        self.reset_view()
    
    def mouseMoved(self, evt):
        """Handle mouse movement to update crosshairs and tooltip."""
        # Unpack the tuple if we received one
        if isinstance(evt, tuple):
            pos = evt[0]  # Get the QPointF from the tuple
        else:
            pos = evt
            
        if self.plot_widget.sceneBoundingRect().contains(pos):
            mousePoint = self.plot_widget.plotItem.vb.mapSceneToView(pos)
            x, y = mousePoint.x(), mousePoint.y()
            
            # Update crosshair positions
            self.vLine.setPos(x)
            self.hLine.setPos(y)
            
            # Find the actual steering values at the cursor position
            steering_value_a = None
            steering_value_b = None
            distance = x
            
            # Find the closest data point for Lap A
            if self.steering_curve.xData is not None and len(self.steering_curve.xData) > 0:
                # Find the closest x point to the cursor
                closest_idx = -1
                min_distance = float('inf')
                
                for i, x_val in enumerate(self.steering_curve.xData):
                    dist = abs(x_val - x)
                    if dist < min_distance:
                        min_distance = dist
                        closest_idx = i
                
                if closest_idx >= 0 and closest_idx < len(self.steering_curve.yData):
                    # Get actual steering value from the data
                    steering_value_a = self.steering_curve.yData[closest_idx] * 100  # Convert to percentage
            
            # In comparison mode, also find the closest data point for Lap B
            if self.comparison_mode and self.steering_curve_b.xData is not None and len(self.steering_curve_b.xData) > 0:
                # Find the closest x point to the cursor
                closest_idx = -1
                min_distance = float('inf')
                
                for i, x_val in enumerate(self.steering_curve_b.xData):
                    dist = abs(x_val - x)
                    if dist < min_distance:
                        min_distance = dist
                        closest_idx = i
                
                if closest_idx >= 0 and closest_idx < len(self.steering_curve_b.yData):
                    # Get actual steering value from the data
                    steering_value_b = self.steering_curve_b.yData[closest_idx] * 100  # Convert to percentage
            
            # Format tooltip text with steering direction and the actual values
            if steering_value_a is not None:
                # Basic tooltip for single lap
                if not self.comparison_mode or steering_value_b is None:
                    direction_a = "Right" if steering_value_a > 0 else "Left"
                    if abs(steering_value_a) < 1.0:  # Close to zero
                        direction_a = "Center"
                        
                    tooltip = f"""
                        <div style='background-color: rgba(0, 0, 0, 180); padding: 5px;'>
                            <span style='color: white;'>Dist: {distance:.1f}m</span><br>
                            <span style='color: #00AAFF;'>Steering {direction_a}: {abs(steering_value_a):.0f}%</span>
                        </div>
                    """
                else:
                    # Enhanced tooltip for comparison
                    direction_a = "Right" if steering_value_a > 0 else "Left"
                    if abs(steering_value_a) < 1.0:
                        direction_a = "Center"
                        
                    direction_b = "Right" if steering_value_b > 0 else "Left"
                    if abs(steering_value_b) < 1.0:
                        direction_b = "Center"
                    
                    tooltip = f"""
                        <div style='background-color: rgba(0, 0, 0, 180); padding: 5px;'>
                            <span style='color: white;'>Dist: {distance:.1f}m</span><br>
                            <span style='color: #00AAFF;'>Lap A: {direction_a} {abs(steering_value_a):.0f}%</span><br>
                            <span style='color: #88CCFF;'>Lap B: {direction_b} {abs(steering_value_b):.0f}%</span>
                        </div>
                    """
                
                self.label.setHtml(tooltip)
                self.label.setPos(x, -0.9)  # Position tooltip at top of graph
    
    def reset_view(self):
        """Reset the view to show the entire lap from start to finish."""
        try:
            # Temporarily enable auto-ranging
            self.plot_widget.plotItem.vb.enableAutoRange()

            # Set fixed Y range for steering (-100% to 100%)
            self.plot_widget.setYRange(-1, 1, padding=0.05)
            
            # Set X range to track length if available, otherwise use a default
            if self.track_length and self.track_length > 0:
                self.plot_widget.setXRange(0, self.track_length, padding=0)
            else:
                self.plot_widget.setXRange(0, 1000, padding=0)

            # Disable auto-ranging again
            self.plot_widget.plotItem.vb.disableAutoRange()
        except Exception as e:
            print(f"Error in reset_view: {e}")
            # Ensure auto-range is disabled on error
            try:
                self.plot_widget.plotItem.vb.disableAutoRange()
            except Exception: # Handle potential nested errors
                pass
    
    def clear_track_markers(self):
        """Clear all track context markers from the graph."""
        # Remove all corner markers
        for marker in self.track_markers:
            self.plot_widget.removeItem(marker)
        self.track_markers = []
    
    def add_corner_marker(self, position, corner_number):
        """Add a corner marker at the specified position."""
        # Create corner marker as a vertical line with label
        corner_marker = pg.InfiniteLine(
            angle=90, 
            movable=False,
            pen=pg.mkPen('c', width=1, style=Qt.DotLine),
            label=f"C{corner_number}", 
            labelOpts={'position': 0.9, 'color': 'c', 'fill': (0, 0, 0, 100)}
        )
        corner_marker.setPos(position)
        self.plot_widget.addItem(corner_marker, ignoreBounds=True)
        self.track_markers.append(corner_marker)
    
    def add_distance_marker(self, position, label=None):
        """Add a distance marker at the specified position."""
        # If no label provided, format position as distance
        if label is None:
            label = f"{int(position)}m"

        # Create distance marker as a vertical line with label
        distance_marker = pg.InfiniteLine(
            angle=90, 
            movable=False,
            pen=pg.mkPen('w', width=1, style=Qt.DotLine),
            label=label, 
            labelOpts={'position': 0.05, 'color': 'w', 'fill': (0, 0, 0, 100)}
        )
        distance_marker.setPos(position)
        self.plot_widget.addItem(distance_marker, ignoreBounds=True)
        self.track_markers.append(distance_marker)
    
    def update_graph_comparison(self, lap_a_data, lap_b_data, track_length, track_context=None):
        """Update the graph to display a comparison of two laps."""
        logger.info(f"Updating steering graph with comparison data for A:{len(lap_a_data['points']) if lap_a_data else 'None'} and B:{len(lap_b_data['points']) if lap_b_data else 'None'} points")
        
        # Set comparison mode flag to True
        self.comparison_mode = True
        
        # --- COMPLETELY RESET PLOT STATE ---
        # Clear both curves by setting empty data arrays
        self.steering_curve.setData([], [])
        self.steering_curve_b.setData([], [])
        
        # Reset plot items and state
        if self.legend:
            self.legend.clear()
            
        # Clear all additional items from the plot that might be leftover
        for item in self.plot_widget.items():
            if item not in [self.steering_curve, self.steering_curve_b, self.vLine, self.hLine, self.label, self.zero_line]:
                self.plot_widget.removeItem(item)
                
        # Clear any message text
        if hasattr(self, 'message_text') and self.message_text and self.message_text in self.plot_widget.items():
             self.plot_widget.removeItem(self.message_text)
             self.message_text = None
             
        # Clear all track markers
        self.clear_track_markers()
        # --- END COMPLETE RESET ---

        # --- Ensure curves, zero line, and legend exist --- 
        self.steering_curve.show()
        self.steering_curve_b.show()
        if self.zero_line not in self.plot_widget.items():
            self.plot_widget.addItem(self.zero_line)
        if self.legend is None:
            # Create a new legend with proper styling if it doesn't exist
            self.legend = self.plot_widget.addLegend(offset=(-20, 10), labelTextSize='10pt')
        # ------------------------------------------------
        
        # Initialize variable for lap processing
        max_dist_overall = 0
        
        # --- Helper Function to Process Lap ---
        def process_lap(lap_dict):
            nonlocal max_dist_overall
            points = lap_dict.get('points', [])
            if not points: return None, None

            distances = []
            steering_values = []

            for point in points:
                # Use 'LapDist' key for distance (expecting meters now)
                if 'LapDist' in point:
                    dist = point['LapDist']
                else: continue

                raw_steering = point.get('SteeringWheelAngle', point.get('steering', 0))
                steering = self.normalize_steering(raw_steering)

                distances.append(dist)
                steering_values.append(np.clip(steering, -1, 1))

            if distances:
                max_dist_overall = max(max_dist_overall, max(distances))
                return distances, steering_values
            return None, None
        # --- End Helper ---

        # Process main lap (Lap A)
        main_distances, main_steering = process_lap(lap_a_data)
        if main_distances:
            self.steering_curve.setData(main_distances, main_steering)
            logger.info(f"Set Lap A steering data with {len(main_distances)} points")
        else:
            logger.warning("No valid data for Lap A")
            self.steering_curve.hide()

        # Process comparison lap (Lap B)
        comp_distances, comp_steering = process_lap(lap_b_data)
        if comp_distances:
            self.steering_curve_b.setData(comp_distances, comp_steering)
            logger.info(f"Set Lap B steering data with {len(comp_distances)} points")
        else:
            logger.warning("No valid data for Lap B")
            self.steering_curve_b.hide() # Ensure hidden if no data

        # Ensure the legend is populated AFTER setting data
        if self.legend:
            self.legend.clear()  # Make sure to clear the legend again before adding items
            if main_distances:
                 self.legend.addItem(self.steering_curve, "Lap A Steering")
            if comp_distances:
                 self.legend.addItem(self.steering_curve_b, "Lap B Steering")

        # Determine track length
        self.track_length = 0
        track_context = lap_a_data.get('track_context') if lap_a_data else (lap_b_data.get('track_context') if lap_b_data else None)
        if lap_a_data and lap_a_data.get('track_length'): self.track_length = lap_a_data['track_length']
        elif lap_b_data and lap_b_data.get('track_length'): self.track_length = lap_b_data['track_length']
        display_range_max = self.track_length if self.track_length > 0 else max(max_dist_overall * 1.05, 1000)

        # Update title and axis ranges
        self.plot_widget.setTitle("Steering vs Distance (Comparison)")
        self.plot_widget.setXRange(0, display_range_max, padding=0)
        self.plot_widget.setYRange(-1, 1, padding=0.05)
        
        # Add track context markers (should be added after curves)
        self._add_track_context_markers(track_context, display_range_max)
        
        # Re-add crosshairs and labels
        if self.vLine not in self.plot_widget.items(): self.plot_widget.addItem(self.vLine, ignoreBounds=True)
        if self.hLine not in self.plot_widget.items(): self.plot_widget.addItem(self.hLine, ignoreBounds=True)
        if self.label not in self.plot_widget.items(): self.plot_widget.addItem(self.label, ignoreBounds=True)
        
        # Add grid
        self.plot_widget.showGrid(x=True, y=True, alpha=0.3)
        
        # Force a redraw of the plot
        self.plot_widget.update()

    def update_graph(self, lap_data, track_length, track_context=None):
        """Update the graph with new lap data using distance as X-axis."""
        try:
            # Ensure comparison mode is off and comparison curve is hidden
            self.comparison_mode = False
            self.steering_curve_b.hide()

            # Store track length for view resets
            self.track_length = track_length
            
            # Clear markers only
            self.clear_track_markers()
            
            # Ensure zero line is present (it might be cleared by other updates)
            self.plot_widget.addItem(self.zero_line)
            
            # Hide message if it exists
            if self.message_text:
                self.message_text.setVisible(False)

            # Handle empty data case
            if not lap_data:
                self.steering_curve.setData([], []) # Clear main curve
                self.display_message("No Lap Data")
                self.reset_view()
                return

            # Extract data
            try:
                # Use 'LapDist' key for distance (in meters)
                distances = [max(0, point["LapDist"]) for point in lap_data]
                steerings = [self.normalize_steering(point.get('SteeringWheelAngle', point.get('steering', 0))) for point in lap_data]
            except KeyError as key_err:
                print(f"Missing required steering data key: {key_err}")
                self.steering_curve.setData([], [])
                self.display_message(f"Data Error: Missing {key_err}")
                self.reset_view()
                return

            if not distances:
                self.steering_curve.setData([], [])
                self.display_message("No Distance Data")
                self.reset_view()
                return
                
            # Calculate display range
            max_dist = max(distances)
            display_range_max = track_length if track_length and track_length > 0 else max(max_dist * 1.05, 1000)
                
            # Clamp steering data just in case normalization wasn't perfect
            steerings_clamped = np.clip(steerings, -1, 1)
            
            # Temporarily enable auto-range for programmatic updates
            self.plot_widget.plotItem.vb.enableAutoRange()
            
            # Update existing main curve using setData
            self.steering_curve.setData(distances, steerings_clamped)
            self.steering_curve.show()

            # Set view ranges
            self.plot_widget.setYRange(-1, 1, padding=0.05)
            self.plot_widget.setXRange(0, display_range_max, padding=0)

            # Disable auto-ranging again
            self.plot_widget.plotItem.vb.disableAutoRange()
            
            # Add track context markers
            self._add_track_context_markers(track_context, display_range_max)
            
            # Ensure grid is visible
            self.plot_widget.showGrid(x=True, y=True, alpha=0.3)
            
            # Update title for single lap view
            self.plot_widget.setTitle("Steering vs Distance")
            
        except Exception as e:
            print(f"Error updating steering graph: {e}")
            import traceback
            print(traceback.format_exc())
            self.steering_curve.setData([], [])
            self.display_message("Graph Update Error")
            self.reset_view() 

    def update_comparison_data(self, main_data, comparison_data):
        """Update the graph with both main lap data and comparison lap data.
        
        Args:
            main_data: Dictionary with stats and points for the main lap
            comparison_data: Dictionary with stats and points for the comparison lap
        
        Returns:
            bool: True if successful, False otherwise
        """
        try:
            self.comparison_mode = True
            
            # Clear markers only
            self.clear_track_markers()
            
            # Ensure zero line is present
            self.plot_widget.addItem(self.zero_line)
            
            # Hide message if it exists
            if self.message_text:
                self.message_text.setVisible(False)

            if not main_data and not comparison_data:
                self.steering_curve.setData([], [])
                self.steering_curve_b.setData([], [])
                self.display_message("No valid data for either lap")
                return False
            
            # Store combined max distance
            max_dist_overall = 0
            
            # --- Helper Function to Process Lap ---
            def process_lap(lap_dict):
                nonlocal max_dist_overall
                points = lap_dict.get('points', [])
                if not points: return None, None
                
                distances = []
                steering_values = []
                
                for point in points:
                    # Use 'LapDist' key for distance (expecting meters now)
                    if 'LapDist' in point:
                        dist = point['LapDist']
                    else: continue
                        
                    raw_steering = point.get('SteeringWheelAngle', point.get('steering', 0))
                    steering = self.normalize_steering(raw_steering)
                    
                    distances.append(dist)
                    steering_values.append(np.clip(steering, -1, 1))
                
                if distances:
                    max_dist_overall = max(max_dist_overall, max(distances))
                    return distances, steering_values
                else:
                    return None, None
            # --- End Helper ---

            # Process main lap (Lap A)
            main_distances, main_steerings = process_lap(main_data)
            if main_distances:
                self.steering_curve.setData(main_distances, main_steerings)
                self.steering_curve.show()
            else:
                self.steering_curve.setData([], [])

            # Process comparison lap (Lap B)
            comp_distances, comp_steerings = process_lap(comparison_data)
            if comp_distances:
                self.steering_curve_b.setData(comp_distances, comp_steerings)
                self.steering_curve_b.show()
            else:
                self.steering_curve_b.setData([], [])
                self.steering_curve_b.hide() # Hide if no data

            # Determine track length
            self.track_length = 0
            track_context = main_data.get('track_context') if main_data else (comparison_data.get('track_context') if comparison_data else None)
            if main_data and main_data.get('track_length'): self.track_length = main_data['track_length']
            elif comparison_data and comparison_data.get('track_length'): self.track_length = comparison_data['track_length']
            display_range_max = self.track_length if self.track_length > 0 else max(max_dist_overall * 1.05, 1000)

            # Update title and axis ranges
            self.plot_widget.setTitle("Steering vs Distance (Comparison)")
            self.plot_widget.setXRange(0, display_range_max, padding=0)
            self.plot_widget.setYRange(-1, 1, padding=0.05)
            
            # Add context markers
            self._add_track_context_markers(track_context, display_range_max)
            self.plot_widget.showGrid(x=True, y=True, alpha=0.3)
            
            # Ensure legend is updated
            if self.legend:
                self.legend.clear()
                self.legend.addItem(self.steering_curve, "Lap A Steering")
                if comp_distances: # Only add comparison item if it has data
                     self.legend.addItem(self.steering_curve_b, "Lap B Steering")

            return True

        except Exception as e:
            print(f"Error updating comparison steering graph: {e}")
            import traceback
            print(traceback.format_exc())
            self.steering_curve.setData([], [])
            self.steering_curve_b.setData([], [])
            self.display_message("Comparison Update Error")
            return False

    def _add_track_context_markers(self, track_context, display_range_max):
        """Adds context markers (corners, distance) to the steering graph."""
        if track_context:
            # No start/finish line on steering graph usually
            if 'corners' in track_context:
                for corner_pos, corner_num in track_context['corners']:
                    self.add_corner_marker(corner_pos, corner_num)
            if 'markers' in track_context:
                for marker in track_context['markers']:
                    self.add_distance_marker(marker[0], marker[1] if isinstance(marker, tuple) else None)
            elif display_range_max > 0: # Auto-generate distance markers
                 marker_interval = 500 if display_range_max <= 5000 else 1000
                 for pos in range(marker_interval, int(display_range_max), marker_interval):
                     self.add_distance_marker(pos)

    def find_max_distance(self, main_points, comparison_points):
        """Find the maximum distance value from both datasets."""
        max_main = max([p.get('track_position', 0) for p in main_points]) if main_points else 0
        max_comp = max([p.get('track_position', 0) for p in comparison_points]) if comparison_points else 0
        return max(max_main, max_comp, 100)  # Default to at least 100m if both are smaller 

    def normalize_steering(self, steering_value):
        """Normalize steering input to a -1.0 to 1.0 range.
        
        Args:
            steering_value: The raw steering value
            
        Returns:
            float: Normalized steering value between -1.0 and 1.0
        """
        # Handle None or invalid values
        if steering_value is None:
            return 0.0
        
        try:
            steering_value = float(steering_value)
        except (ValueError, TypeError):
            return 0.0
        
        # If steering is already in -1.0 to 1.0 range, return it as is
        if -1.0 <= steering_value <= 1.0:
            return steering_value
        
        # If steering is in radians (typically -3pi to 3pi for 1080 degree wheels)
        if abs(steering_value) > 1.0:
            # Use a standard 1080-degree wheel assumption (3 full rotations)
            max_rotation = 3.0 * math.pi  # ~9.42 radians
            # Normalize to -1.0 to 1.0 range
            return max(-1.0, min(1.0, steering_value / max_rotation))
        
        return steering_value

    def display_message(self, message):
        """Display a message on the graph when no data is available.
        
        Args:
            message: Message to display
        """
        # Clear any existing data
        self.steering_curve.setData([], [])
        
        # Add a text item to the center of the plot
        if not hasattr(self, 'message_text') or self.message_text is None:
            self.message_text = pg.TextItem(
                text=message,
                color=(200, 200, 200),
                anchor=(0.5, 0.5),
                fill=(0, 0, 0, 100)
            )
            self.plot_widget.addItem(self.message_text)
        else:
            self.message_text.setText(message)
            self.message_text.setVisible(True)
        
        # Position text in center
        view_range = self.plot_widget.viewRange()
        x_center = (view_range[0][0] + view_range[0][1]) / 2
        y_center = (view_range[1][0] + view_range[1][1]) / 2
        self.message_text.setPos(x_center, y_center)
        
        # Make sure the plot still has a reasonable display range
        self.reset_view() 